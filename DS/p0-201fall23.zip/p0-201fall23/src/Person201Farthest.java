public class Person201Farthest{
    public static void main(String[] args) throws Exception {
        String file = "large.txt";
        double max = 0;
        Person201 a = null;
        Person201 b = null;
        Person201[] people = Person201Utilities.readFile(file);
        double d;
        for (Person201 p : people) {
            for (Person201 q : people) {
                d = p.distanceFrom(q);
                if (d > max) {
                    a = p;
                    b = q;.
                    max = d;
                }
            }
        }
        System.out.printf("farthest distance is %3.2f between %s and %s\n",max,a.getName(),b.getName());

    }
}